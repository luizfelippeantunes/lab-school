package projeto1v2.models;

public interface AtendimentoPedagogico {
    void incrementoAtendimentoPedagogico();
    void iniciaAtendimentoPedagogico();
    void finalizaAtendimentoPedagogico();
}
