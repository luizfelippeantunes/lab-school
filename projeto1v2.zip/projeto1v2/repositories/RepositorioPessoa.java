package projeto1v2.repositories;

import projeto1v2.models.Pessoa;

import java.util.ArrayList;
import java.util.List;

public abstract class RepositorioPessoa {

    public static List<Pessoa> repositorioPessoas = new ArrayList<>();
}